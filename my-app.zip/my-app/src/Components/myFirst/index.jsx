import React , { Component }from 'react';

class MyFirst extends Component {
  
    render() {
      return <h3>React First Component</h3>;
    }
  }

export default MyFirst;               