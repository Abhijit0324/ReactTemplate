import { combineReducers } from 'redux';
import Reducer from './reducerAction'; //add this line
import serviceCall from './serviceCall'

const rootReducer = combineReducers({
      Reducer , //add reducer for future use.
      serviceCall
  });

  
export default rootReducer;