import initialState from '../initialState';

import * as ActionType from  '../Action/ActionType';

function serviceCall (state = initialState, action) {
 
    switch (action.type) {
      case ActionType.ADD_SERVICE_CALL:
        console.log(">>>>> reducer call ADD_SERVICE_CALL")
        return state;
      default:
        return state
    }
  }

export default serviceCall;