/*
 * action types
 */

export const  ADD_NAME = 'ADD_NAME';
export const  ADD_SERVICE_CALL = 'ADD_SERVICE_CALL';

//export default 
