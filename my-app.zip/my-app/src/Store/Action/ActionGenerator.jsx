import * as ActionType from  './ActionType';


export function setName(firstName, lastName) {
    return {
        type: ActionType.ADD_NAME,
        firstName: firstName,
        lastName: lastName
    };
}

