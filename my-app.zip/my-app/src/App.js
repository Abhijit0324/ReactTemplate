import React , { Component } from 'react';
import './App.css';
import  MyFirst from './Components/myFirst';
import  MySecond from './Components/mySecond';
import { connect } from 'react-redux';
import {setName} from './Store/Action/ActionGenerator';


class App extends Component {
  constructor(props) {
    super(props);
    //Just shown how to declare Local State.
    this.state = {
      Fname: 'Satish',
      lname: 'Joshi'
    };
  }

  componentDidMount(){
    console.log("CallLog componentDidMount")

    this.props.setNameEvent('Abhijit', 'Banerjee');
  }
    
    render() {
    return (
      <div className="App">
      <h1>My Application Template </h1>

      <h3>Global State : {this.props.firstName}</h3>

      <h3>Local State : {this.state.Fname}</h3>
         
        <MyFirst />
        <MySecond />
    </div>
    )

    }
  }

  const mapDispatchToProps = dispatch => ({
    setNameEvent: (firstName, lastName) => dispatch(setName(firstName, lastName))
  });

  const mapStateToProps = (state) => {
    return {
        firstName: state.Reducer.firstName
    };
  }

export default connect(mapStateToProps,  mapDispatchToProps)(App);               

